var userName = ["user-1", "user-2", "user-3", "user-4"];

// for (let i = 0; i < userName.length; i++) {
//     if (userName[i] === "user-2") {
//         alert("This is a uesr-2")
//         console.log(userName[i])
//     }
// }
// var i = 0;
// while (i < userName.length) {
//     if (userName[i] === "user-2") {
//         alert("This is a uesr-2")
//     }
//     i++
// }
// var i = 0;
// do {
//     if (userName[i] === "user-2") {
//         alert("This is a User 2")
//     }
//     i++
// } while (i < userName.length);