var x = document.getElementById("my").innerHTML = 'Hello world';
var item1  = 50;
var item2 = 30; 
var item3 = 20;

var totalPrice = item1+item2-item3;
// alert(totalPrice);

console.log("item1 50 + item2 20 - item 10");

console.log(totalPrice);

var book1 = 40;
var book2 = 40;
var book3 = 40;

var mybudget = 200;

var totalbudget = book1+book2+book3;

console.log("My Budget",mybudget);

var checkOut = mybudget-totalbudget;

console.log(checkOut);