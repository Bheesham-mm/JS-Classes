// confirm('Are you sure Delete File!');

// var arr = ["Name", "Values", "Elements"];

// var filterData = arr.filter((a,b)=>{
//     var firstWord = a.length;
//     return firstWord >= 8;
// })
// console.log(filterData)

// var arr = [0,1,2,3,4,5,6,7,8,9,10]
// var numFilter = arr.filter((a)=>{
//     return (a % 2) === 0;
// })
// console.log(numFilter)

// var Subject = prompt("Enter your favourite Subject");
// switch(Subject){
//     case "English":
//         alert("English");
//         console.log("English")
//     break;
//     case "Physics":
//         alert("Physics");
//         console.log("Physics")
//     break;
//     default:
//         alert("subject is Not found")
//         console.log("Subject is not found")
// }