function submitForm() {
    var email = document.getElementById('email').value
    var pass = document.getElementById('pass').value
    localStorage.setItem('email', email)
    localStorage.setItem('password', pass)

    if (email === '') {
        alert('fill the form')
    } else if (pass === '') {
        alert('password empty')
    }
    else {
        window.open('home.html', 'win1', 'width:300px')
    }
}