let a = Number(prompt("Enter a number"));

if (a > 0) {
    alert("Number is positive.");
    console.log("Number is positive.");
}
if (a < 1) {
    alert("Number is negative.");
    console.log("Number is negative.");
}
if (a === 0) {
    alert("Number is zero.");
    console.log("Number is zero.");
}
console.log(a);