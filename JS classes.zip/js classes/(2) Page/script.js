// Data type number & strins

// string
var c = "Hello world";

console.log("This is type of a string");
console.log(c);


// number
var a = 6;
var b = 10;

var total = a+b;
console.log("This is Data type of a number");
console.log(total);


// number and string 
var strinG = "num! ";
var numbeR = 10;

var connected = strinG+numbeR;
console.log(connected);

// test

var ab = 10;
var dc = 3;

var total_count = ab%dc;
console.log(total);

// nat a number 

var notAnumber = "Hello";
var Notanumber = "10";

var notAnumber1 = notAnumber - notAnumber;

console.log(notAnumber1);