var companyName = document.getElementById('firstname');
var userName = document.getElementById('name');
var mail = document.getElementById('mail');
var phoneNumer = document.getElementById('phone');
var linkUrl = document.getElementById('link');
var description = document.getElementById('desc');
var getImage = document.getElementById('upload');
var resetValue = document.getElementById('resetFun');

// Reset function
resetValue.addEventListener('click', function () {
    companyName.value = '';
    userName.value = '';
    mail.value = '';
    phoneNumer.value = '';
    linkUrl.value = '';
    description.value = '';
    getImage.value = '';
});

// Form Validation
function validateForm() {
    var isValid = true;

    // Validate Company Name
    if (companyName.value.trim() === '') {
        document.getElementById('errorCN').innerHTML = 'Company Name is required';
        isValid = false;
    } else if (companyName.value.length < 8) {
        document.getElementById('errorCN').innerHTML = 'Company Name must be at least 8 characters';
        isValid = false;
    } else {
        document.getElementById('errorCN').innerHTML = '';
    }

    // Validate User Name
    if (userName.value.trim() === '') {
        document.getElementById('errorF').innerHTML = 'Name is required';
        isValid = false;
    } else if (userName.value.length < 8) {
        document.getElementById('errorF').innerHTML = 'Name must be at least 8 characters';
        isValid = false;
    } else {
        document.getElementById('errorF').innerHTML = '';
    }

    // Validate Email
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (mail.value.trim() === '') {
        document.getElementById('errorD').innerHTML = 'Email is required';
        isValid = false;
    } else if (!emailPattern.test(mail.value)) {
        document.getElementById('errorD').innerHTML = 'Invalid Email format';
        isValid = false;
    } else {
        document.getElementById('errorD').innerHTML = '';
    }

    // Validate Phone Number
    if (phoneNumer.value.trim() === '') {
        document.getElementById('errorR').innerHTML = 'Phone number is required';
        isValid = false;
    } else if (phoneNumer.value.length < 10) {
        document.getElementById('errorR').innerHTML = 'Phone number must be 10 digits';
        isValid = false;
    } else {
        document.getElementById('errorR').innerHTML = '';
    }

    // Validate Link
    var urlPattern = /^(https?:\/\/)?([\w\d\-_]+\.+[A-Za-z]{2,})+\/?/;
    if (linkUrl.value === '') {
        document.getElementById('errorL').innerHTML = 'Link is required';
        isValid = false;
    } else if (!urlPattern.test(linkUrl.value)) {
        document.getElementById('errorL').innerHTML = 'Invalid URL format! || https://www.yoursite.com';
        isValid = false;
    } else {
        document.getElementById('errorL').innerHTML = '';
    }

    // Validate Description
    if (description.value.trim() === '') {
        document.getElementById('errorA').innerHTML = 'Description is required';
        isValid = false;
    } else if (description.value.length < 20) {
        document.getElementById('errorA').innerHTML = 'Description must be at least 20 characters';
        isValid = false;
    } else {
        document.getElementById('errorA').innerHTML = '';
    }

    return isValid;
}

function generateCard() {
    // Data get in array of object
    var dataObject = {
        Cname: companyName.value,
        name: userName.value,
        email: mail.value,
        pNumber: phoneNumer.value,
        url: linkUrl.value,
        desc: description.value,
        img: getImage.src,
    }

    // Card Generation Function
    if (validateForm()) {
        // Clear any previous card content
        var container = document.getElementById('cardContainer');
        // container.innerHTML = '';

        Swal.fire({
            position: "top-end",
            icon: "success",
            title: "Your Email Signature Generated Successfully",
            showConfirmButton: false,
            timer: 1500
        });

        // Create table element
        var table = document.createElement('table');
        table.setAttribute('cellpadding', '0');
        table.setAttribute('cellspacing', '0');
        table.setAttribute('border', '0');
        table.style.width = '170%';
        table.style.marginTop = '16px';
        table.classList.add('mainContain');

        // First row - Company Name
        var tr1 = document.createElement('tr');
        var td1 = document.createElement('td');
        td1.setAttribute('colspan', '2');
        td1.style.height = '25px';
        td1.classList.add('nameTd');

        var companySpan = document.createElement('span');
        companySpan.style.fontSize = '14px';
        companySpan.style.fontWeight = 'bold';
        companySpan.textContent = dataObject.Cname;

        td1.appendChild(companySpan);
        tr1.appendChild(td1);

        // Second row - User Info
        var tr2 = document.createElement('tr');
        var td2 = document.createElement('td');
        td2.style.width = '65%';
        td2.setAttribute('valign', 'top');
        td2.classList.add('textContain');

        // User Name
        var userNameP = document.createElement('p');
        userNameP.classList.add('user_name');
        userNameP.textContent = dataObject.name;
        td2.appendChild(userNameP);

        // Email
        var emailP = document.createElement('p');
        emailP.classList.add('email');
        emailP.innerHTML = 'Email: <a class="mail" target="_blank" href="mailto:' + dataObject.email + '">' + dataObject.email + '</a>';
        td2.appendChild(emailP);

        // Mobile number
        var phoneP = document.createElement('p');
        phoneP.classList.add('numberPhon');
        phoneP.innerHTML = 'Mobile: <span class="mob">' + dataObject.pNumber + '</span>';
        td2.appendChild(phoneP);

        // Link
        var linkP = document.createElement('p');
        linkP.innerHTML = 'Link: <a href="' + dataObject.url + '" target="_blank">' + dataObject.url + '</a>';
        td2.appendChild(linkP);

        // Right side images
        var td3 = document.createElement('td');
        td3.setAttribute('align', 'right');

        // Display uploaded image using FileReader
        var img1 = document.createElement('img');
        if (getImage.files.length > 0) {
            var reader = new FileReader();
            reader.onload = function (e) {
                img1.src = e.target.result;
                img1.style.width = '100px';
                img1.style.height = '100px';
            };
            reader.readAsDataURL(getImage.files[0]);
        } else {
            img1.src = 'photo.png';  // Default image if no file is uploaded
            img1.style.width = '100px';
            img1.style.height = '100px';
        }

        var img2 = document.createElement('img');
        img2.setAttribute('src', 'pic.png');

        // AppendChild All Elements
        td3.appendChild(img1);
        td3.appendChild(img2);

        tr2.appendChild(td2);
        tr2.appendChild(td3);

        // Third row - Description
        var tr3 = document.createElement('tr');
        var td4 = document.createElement('td');
        td4.setAttribute('colspan', '2');
        td4.classList.add('desc');
        td4.textContent = dataObject.desc + `<br />`;

        tr3.appendChild(td4);

        // Append rows to table
        table.appendChild(tr1);
        table.appendChild(tr2);
        table.appendChild(tr3);

        // Append table to container
        container.appendChild(table);

        // Clear input values
        companyName.value = '';
        userName.value = '';
        mail.value = '';
        phoneNumer.value = '';
        linkUrl.value = '';
        description.value = '';
        getImage.value = '';
        // Check Data object
        console.log(dataObject)

    } else {
        console.log('Form is invalid');
    }
}