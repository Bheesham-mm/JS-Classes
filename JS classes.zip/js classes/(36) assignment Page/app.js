// get user data
var getSearch = document.getElementById('get_search');
// select container and add search data
var addData = document.getElementById('add_data');

var students = [
    { name: "student1" },
    { name: "student2" },
    { name: "student3" },
    { name: "student4" }
];
function search() {
    var getSearch1 = false;
    for (var i = 0; i < students.length; i++) {
        if (getSearch.value === students[i].name) {
            // console.log(studentSearch)
            addData.innerHTML = `Your Name is Available: ${getSearch.value}`;
            getSearch1 = true;
        }
    }
    if (getSearch1 === false) {
        addData.innerHTML = `user name is not found`;
    }
};