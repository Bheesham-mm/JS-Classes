function openTab() {
    window.open('home.html', 'index', 'width=420,height=380,left=130,top=99');
}