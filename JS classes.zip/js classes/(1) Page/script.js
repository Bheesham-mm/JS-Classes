// first programm
// keywords
// alert("Hello World")

var HelloWorld = "alert";
var a = 5+5;
alert(HelloWorld);
alert(a)