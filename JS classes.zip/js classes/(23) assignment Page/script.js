// var salary = 5000;
// var expensive = 1000;
// function clickMe(sal, exp) {
//     var total = salary-expensive;
//     // console.log(total);
//     var percent = (total/salary)*100;
//     var sallary2 = sal + salary;
//     var expensive2 = exp + expensive;
//     console.log(sallary2)
//     console.log(expensive2)
//     console.log("Total Percentage: " + percent+"%");
// }
// var numbers=[];
// var arr = [2,3,4,5,6,7,8,9,10];
// for (let i = 0; i < arr.length; i++) {
//     const element = arr[i];
//     if (element % 2 === 0) {
//         numbers.push(element)
//     }
// }
// console.log(numbers);