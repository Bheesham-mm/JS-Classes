// Product Array
var ProductArray = {
    Product_1: { name: 'Camera1', para: 'Example description', btn: 'Add to cart', src: "https://www.dpreview.com/files/p/articles/6269402639/canon_eosr8.jpeg" },
    Product_2: { name: 'Camera2', para: 'Example description', btn: 'Add to cart', src: "https://www.dpreview.com/files/p/articles/6269402639/canon_eosr8.jpeg" },
    Product_3: { name: 'Camera3', para: 'Example description', btn: 'Add to cart', src: "https://www.dpreview.com/files/p/articles/6269402639/canon_eosr8.jpeg" },
    Product_4: { name: 'Camera4', para: 'Example description', btn: 'Add to cart', src: "https://www.dpreview.com/files/p/articles/6269402639/canon_eosr8.jpeg" },
    Product_5: { name: 'Camera5', para: 'Example description', btn: 'Add to cart', src: "https://www.dpreview.com/files/p/articles/6269402639/canon_eosr8.jpeg" },
    Product_6: { name: 'Camera6', para: 'Example description', btn: 'Add to cart', src: "https://www.dpreview.com/files/p/articles/6269402639/canon_eosr8.jpeg" }
};

// Variables to store cart items
var cartItems = [];
var cartCount = 0;

// Card select parent element
var parentElem = document.getElementById('container');
var cartBtn = document.getElementById('cart-btn');
var cartItemsList = document.getElementById('cart-items-list');

// Function to update cart count
function updateCartCount() {
    cartBtn.innerHTML = `Add Cart (${cartCount})`;
}

// Function to update the cart modal
function updateCartModal() {
    cartItemsList.innerHTML = '';

    for (let index = 0; index < cartItems.length; index++) {
        var item = cartItems[index];
        var li = document.createElement('li');
        li.classList.add('list-group-item', 'd-flex', 'justify-content-between', 'align-items-center');
        li.innerHTML = `
            ${item.name}
            <span class="badge bg-danger" style="cursor: pointer;" onclick="removeItem(${index})">X</span>
        `;
        cartItemsList.appendChild(li);
    }
}


// Remove item from cart
function removeItem(index) {
    cartItems.splice(index, 1);
    cartCount--;
    updateCartCount();
    updateCartModal();
}

// Get product keys and generate cards
var productKeys = Object.keys(ProductArray);
for (var i = 0; i < productKeys.length; i++) {
    (function (product) {
        // Create card elements
        var card = document.createElement('div');
        card.setAttribute("class", 'card col-lg-4 col-md-6 col-sm-12');
        var cardImage = document.createElement('img');
        cardImage.setAttribute('src', product.src);
        cardImage.setAttribute('class', 'img-top');
        var cardBody = document.createElement('div');
        cardBody.setAttribute('class', 'card-body');
        var cardTitle = document.createElement('h5');
        cardTitle.setAttribute('class', 'card-title');
        cardTitle.innerHTML = product.name;
        var cardText = document.createElement('p');
        cardText.setAttribute('class', 'card-text');
        cardText.innerHTML = product.para;
        var btnPrimary = document.createElement('button');
        btnPrimary.setAttribute('class', 'btn btn-primary');
        btnPrimary.innerHTML = product.btn;

        // Add product to cart on button click
        btnPrimary.addEventListener('click', function () {
            cartItems.push(product);
            cartCount++;
            updateCartCount();
            updateCartModal();
        });

        // Append elements to DOM
        parentElem.appendChild(card);
        card.appendChild(cardImage);
        card.appendChild(cardBody);
        cardBody.appendChild(cardTitle);
        cardBody.appendChild(cardText);
        cardBody.appendChild(btnPrimary);
    })(ProductArray[productKeys[i]]);
}

// Show cart modal
cartBtn.addEventListener('click', function () {
    var cartModal = new bootstrap.Modal(document.getElementById('cartModal'));
    cartModal.show();
});

// Checkout button functionality
document.getElementById('checkout-btn').addEventListener('click', function () {
    alert('Proceeding to checkout');
    // Implement your checkout logic here
});
