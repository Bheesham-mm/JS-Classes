// for (var i = 1; i <= 10; i++) {
//     // console.log(i + " x " + "2" + " = " + i * 2);
//     document.write(i + " x " + "2" + " = " + i * 2);
//     document.write("<br>")
// }
// for (var e = 1; e <= 10; e++) {
//     console.log(e + " x " + "3" + " = " + e * 3);
// }

var eventDate = "Auguest 20, 2024";
var oldDate = new Date("Auguest 20, 2024");
var oldDateInMilliSecods = oldDate.getTime();
var NewDate = new Date();
var currentDateAndOld = oldDate-NewDate;
var currentDate = currentDateAndOld/(1000*60*60*24);
console.log(Math.ceil(currentDate));