// var arr = ["a", "b", "c", "d", "e", "f", "g", "h", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"];
// var random = Math.floor(Math.random()*10) + 1;
// console.log("Random " + random);
// var newRandom = random*2;
// var randomLetters = arr.slice(newRandom, random);
// // console.log(newRandom, random)
// console.log("Random Letters " + randomLetters);

// var letters = [
//     "A","B","C","D","E","F","G","H","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","Y","X","Z"
// ]; 
// // console.log(Letters)
// var randomNum = Math.floor(Math.random()*10+1);
// // randomNum*2;
// console.log("Random Numbers "+randomNum)
// var randomletters = letters.slice(randomNum, randomNum*2)
// console.log(randomletters)
// function showFunction() {
//     document.write(randomletters)
// }


var fname = " Bheesham";
var lname = " Kumar";

function clickMe(value1, value2) {
    var concenet = value1+fname;
    var concenet2 = value2+lname;
    console.log(concenet, concenet2)
}