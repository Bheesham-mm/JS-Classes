// function seeMore() {
//     var SeeMore = document.getElementById('para').innerText =
//      "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sint maiores laudantium, repudiandae corporis iste unde expedita dolorum odio quas magni dolor a ab porro nemo doloremque! Soluta odit eum blanditiis!  Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sint maiores laudantium, repudiandae corporis iste unde expedita dolorum odio quas magni dolor a ab porro nemo doloremque! Soluta odit eum blanditiis!";
// }
// function seeLess() {
//     var seeLess = document.getElementById('para').innerText =
//     "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sint maiores laudantium, repudiandae corporis iste unde expedita dolorum odio quas magni dolor a ab porro nemo doloremque! Soluta odit eum blanditiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sint maiores laudantium, repudiandae corporis iste unde expedita dolorum odio quas magni dolor a ab porro nemo doloremque! Soluta odit eum blanditiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sint maiores laudantium, repudiandae corporis iste unde expedita dolorum odio quas magni dolor a ab porro nemo doloremque! Soluta odit eum blanditiis!";
// }

function togle(type) {
    var seemore = 
        "consectetur adipisicing elit. Sint maiores laudantium, repudiandae corporis iste unde expedita dolorum odio quas magni dolor a ab porro nemo doloremque! Soluta odit eum blanditiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sint maiores laudantium, repudiandae corporis iste unde expedita dolorum odio quas magni dolor a ab porro nemo doloremque! Soluta odit eum blanditiis! Lorem ipsum, dolor sit amet";
    var seeLess = 
        "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sint maiores laudantium, repudiandae corporis iste unde expedita dolorum odio quas magni dolor a ab porro nemo doloremque! Soluta odit eum blanditiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sint maiores laudantium, repudiandae corporis iste unde expedita dolorum odio quas magni dolor a ab porro nemo doloremque! Soluta odit eum blanditiis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sint maiores laudantium, repudiandae corporis iste unde expedita dolorum odio quas magni dolor a ab porro nemo doloremque! Soluta odit eum blanditiis!";
    if (type === "seeless") {
        // console.log(document.getElementById('para'))
        document.getElementById('para').innerText += seemore;
    }else{
        document.getElementById('para').innerText = seeLess;
    }
}