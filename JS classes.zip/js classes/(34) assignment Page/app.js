var parentElement = document.getElementsByTagName('body')[0];
// console.log(parentElement);
// console.log(parentElement)
var container = document.createElement('div');
container.setAttribute('class', 'container');
parentElement.appendChild(container);
var uploadbtn = document.createElement('label');
var uploadbtnInp = document.createElement('input');
uploadbtnInp.type = 'file';
uploadbtnInp.id = 'file1';
uploadbtn.setAttribute('for', 'file1')
uploadbtn.className = 'button'
uploadbtn.innerText = 'Upload Logo';
container.appendChild(uploadbtn);
uploadbtn.appendChild(uploadbtnInp);
var para = document.createElement('p');
para.innerText = 'Custmize Text (front side) '
container.appendChild(para);
var inp1 = document.createElement('input');
inp1.type = 'text';
inp1.setAttribute('placeholder', 'Home Address')
container.appendChild(inp1);
var lineBreack = document.createElement('br');
container.appendChild(lineBreack)
var inp2 = document.createElement('input');
inp2.type = 'text';
inp2.setAttribute('placeholder', 'manager')
container.appendChild(inp2);
var lineBreack = document.createElement('br');
container.appendChild(lineBreack)
var inp3 = document.createElement('input');
inp3.type = 'text';
inp3.setAttribute('placeholder', 'Johan Deo')
container.appendChild(inp3);
var lineBreack = document.createElement('br');
container.appendChild(lineBreack)
var addMoreTextbtn = document.createElement('button');
addMoreTextbtn.innerText = 'Add More Text';
addMoreTextbtn.className = 'btnA'
container.appendChild(addMoreTextbtn);
var lineBreack = document.createElement('br');
container.appendChild(lineBreack)
var addToCartBtn = document.createElement('button');
addToCartBtn.className = 'btnA';
addToCartBtn.innerText = 'Add to cart';
container.appendChild(addToCartBtn);

addMoreTextbtn.addEventListener('click', function () {
    alert('No more text...!');
})
addToCartBtn.addEventListener('click', function () {
    alert('Item is added...!');
});