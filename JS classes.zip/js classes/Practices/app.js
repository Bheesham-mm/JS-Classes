// var getElement = document.getElementById('container').hasAttribute('class'); // Check if the element has a 'class' attribute
// console.log(getElement); // Logs true if 'class' attribute exists, false otherwise
// var getElement1 = document.getElementById('container').getAttribute('class'); // Retrieves the 'class' attribute value
// console.log(getElement1); // Logs the value of the 'class' attribute, or null if it doesn't exist