// #############    Assignment One     ########## /// 

// Prompt the user to enter the first letter of a vowel
var letter = prompt("Enter The Wovel first Letter");

// Check if the entered letter is 'a' or 'A'
if (letter === "a" || letter === "A"){
    // If true, display "Your Correct Answer"
    document.write("Your Correct Answare");
} 
// Check if the entered letter is 'e' or 'E'
else if (letter === "e" || letter === "E"){
    // If true, display "Your Correct Answer"
    document.write("Your Correct Answare");
}
// Check if the entered letter is 'i' or 'I'
else if (letter === "i" || letter === "I"){
    // If true, display "Your Correct Answer"
    document.write("Your Correct Answare");
}
// Check if the entered letter is 'o' or 'O'
else if (letter === "o" || letter === "O"){
    // If true, display "Your Correct Answer"
    document.write("Your Correct Answare");
}
// Check if the entered letter is 'u' or 'U'
else if (letter === "u" || letter === "U"){
    // If true, display "Your Correct Answer"
    document.write("Your Correct Answare");
}
// If none of the above conditions are met
else {
    // Display "Your Answer is Wrong"
    document.write("Your Answare Wrong");
}


// ##############  Assignment two   ########### //

// Define a variable with the correct password
var pass = "Personal123";

// Prompt the user to enter their password
var userPass = prompt("Enter your Password");

// Check if the user did not enter anything
if (userPass === ""){
    // If true, ask the user to try again
    document.write("<h1>Please Try Again and Enter Your Password</h1>");
}
// Check if the entered password matches the correct password or a lowercase version
else if (userPass === pass || userPass === "personal123"){
    // If true, confirm that the form is submitted
    document.write("Your Form Submited");
}
// If the entered password does not match the correct password
else{
    // Ask the user to reload the page and enter the correct password
    document.write("<h1>Please reload your Page And Enter Your Password</h1>");
}
