var studentArray = []
function Student1(name, course, role) {
    this.studentName = name;
    this.course = course;
    this.role = role;
}

var student1 = new Student1("Akash", "Web Development", 9822);
var student2 = new Student1("Bhart", "Web Development", 4324);
var student3 = new Student1("Nitesh", "Web Development", 6432);
var student4 = new Student1("Madan", "Web Development", 9876);
var student5 = new Student1("Mahaveer", "Web Development", 9782);

studentArray.push(student1, student2, student3, student4, student5)
console.log(studentArray)
