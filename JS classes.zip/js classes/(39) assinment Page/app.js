var parentElement = document.getElementById('get_data')
var studentObj = {
    name: "Doef",
    fname: "Random",
    role: "student"
}
for (var prop in studentObj) {
    parentElement.innerHTML += `${prop} ===> ${studentObj[prop]} <br>`
    console.log(parentElement)
}