// Get Todos list name, edit, close
var todo = document.getElementById('todo')
// local div
var localParent = document.createElement('div');
var local = document.createElement('div');
// rendor all todos
local.id = 'clear';
localParent.id = 'local'
todo.appendChild(localParent)
// get user value select input element
var getValue = document.getElementById('getData');
// add todo function
function add() {
    localParent.appendChild(local)
    // console.log(getValue.value)
    if (getValue.value === '') {
        // console.log('empty')
        document.getElementById('error').innerHTML = 'please enter the data'
    } else {

        document.getElementById('error').innerHTML = ''
        // start todo first created main div container
        var mainDiv = document.createElement('div');
        mainDiv.setAttribute('class', 'getItems')
        mainDiv.id = 'delete' // delete todo
        // Todo added item names div
        var item_name = document.createElement('div');
        item_name.setAttribute('class', 'item-name');
        item_name.setAttribute('id', 'change');
        item_name.textContent = getValue.value; // add value input tag getValue
        // Edit todo List item name button
        var item_name_edit = document.createElement('div');
        item_name_edit.setAttribute('class', 'edit');
        var item_name_btn = document.createElement('button');
        item_name_btn.id = 'edit';
        item_name_btn.setAttribute('onclick', 'edit()')
        item_name_btn.innerHTML = 'Edit';
        // Delete todo List Item name button
        var item_name_dele = document.createElement('div');
        item_name_dele.setAttribute('class', 'close');
        var item_name_del = document.createElement('button');
        item_name_del.setAttribute('onclick', 'del()')
        item_name_del.id = 'del';
        item_name_del.innerHTML = 'Delete';
        // AppendChild the All emelemts
        local.appendChild(mainDiv)
        mainDiv.appendChild(item_name)
        item_name_edit.appendChild(item_name_btn)
        mainDiv.appendChild(item_name_edit)
        item_name_dele.appendChild(item_name_del)
        mainDiv.appendChild(item_name_dele)

        // Edit and Delete using AddEventListener
        // item_name_btn.addEventListener("click", function () {
        //     var getNewData = prompt('Enter The New Data')
        //     if (getNewData === '') {
        //         getValue.value = '';
        //         document.getElementById('error').innerHTML = 'please enter the new data';
        //     } else if (getNewData === null) {
        //         getValue.value = '';
        //         item_name.innerHTML;
        //     }
        //     else {
        //         getValue.value = '';
        //         item_name.innerHTML = getNewData;
        //     }
        // });

        // deleting todo using AddEventListener 
        // item_name_del.addEventListener("click", function () {
        //     var funDel = confirm('Are you sure...!')
        //     if (funDel) {
        //         getValue.value = '';
        //         mainDiv.remove(); // This will remove the entire mainDiv when the delete button is clicked
        //     } else { alert('cancled...!') }
        // });

    }
}
// clear all todos list
var clearList = document.createElement('div');
clearList.setAttribute('class', 'close');
clearList.style = 'display: flex; justify-content: flex-end; margin-top: 10px;'
var clearAll = document.createElement('button');
clearAll.setAttribute('onclick', 'clearAllList()')
clearAll.style.background = '#ffc700d9'
clearAll.id = 'del'
clearAll.innerHTML = 'Clear All';
clearList.appendChild(clearAll)
todo.appendChild(clearList)
// console.log(mainParent)
// clear all todos List
function clearAllList() {
    // alert('ok')
    var clearing = confirm('Are you sure clear all list...!')
    if (clearing) {
        getValue.value = '';
        document.getElementById('clear').remove();
    } else { alert('cancled...!') }
}
// Edit And Delete todo list functions
function edit() {
    // get user new value
    var getNewData = prompt('Enter The New Data')
    if (getNewData === '') {
        getValue.value = '';
        document.getElementById('error').innerHTML = 'please enter the new data';
    } else if (getNewData === null) {
        getValue.value = '';
        item_name.innerHTML;
    }
    else {
        getValue.value = '';
        document.getElementById('change').innerHTML = getNewData;
    }
}
function del() {
    var funDel = confirm('Are you sure...!')
    if (funDel) {
        getValue.value = '';
        document.getElementById('delete').remove(); // This will remove the entire mainDiv when the delete button is clicked
    } else { alert('cancled...!') }
}
// end todo
