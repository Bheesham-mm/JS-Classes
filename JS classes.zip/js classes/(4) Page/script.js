// // increment 
// var marks = 100;
// marks --;
// console.log(marks);
// // dicrement
// var marks1 = 100;
// marks1 ++;
// console.log(marks1);


// assignment

var sub1 = prompt("Enter Your English Marks");
var sub2 = prompt("Enter Your Mathametic Marks");
var sub3 = prompt("Enter Your Physics Marks");

// var totalcount = sub1

var totalMarks = sub1+" "+sub2+" "+sub3;

console.log("Your Total Marks =>",totalMarks);

