function paraFun(funParam) {
    // console.log(funParam)
    var para = document.getElementById('paragraph')
    // console.log(para)
    para.className = funParam;
}